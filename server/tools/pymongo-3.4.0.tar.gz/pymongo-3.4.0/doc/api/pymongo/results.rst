:mod:`results` -- Result class definitions
==========================================

.. automodule:: pymongo.results
   :synopsis: Result class definitions
   :members:
   :inherited-members:
